window.onload = function welcomeNotice() 
	{
		var welcome = "Welcome to my new golf website!"
		alert(welcome);
	}
	
document.getElementById("mainImage").addEventListener("click", pick_click);


function pic_click()
	{
		var msg = "Here is a picture of me golfing!";
	    alert(msg);
	}
	 
	 

